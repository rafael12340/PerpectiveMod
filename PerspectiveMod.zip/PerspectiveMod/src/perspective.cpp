#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <cstring>
#include <cstdint>
#include <sys/mman.h>
#include <unistd.h>
#include <fstream>
#include <string>
#include <pthread.h>

#include "pl/Hook.h"
#include "pl/Gloss.h"

#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_opengl3.h"
#include "ImGui/backends/imgui_impl_android.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>

#define LOG_TAG "PerspectiveMod"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ==============================
   Estado global
================================ */

static bool g_modInitialized   = false;
static bool g_imguiInitialized = false;
static int  g_width = 0, g_height = 0;
static EGLContext g_targetContext = EGL_NO_CONTEXT;
static EGLSurface g_targetSurface = EGL_NO_SURFACE;

static EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay, EGLSurface) = nullptr;

// -1 = sem override (jogo controla)
//  0 = 1a pessoa
//  1 = 3a pessoa costas
//  2 = 3a pessoa frente
static int g_perspective = -1;

static int (*g_getPlayerViewPerspective_orig)(void*) = nullptr;

/* ==============================
   GL State Backup
================================ */

struct GLState {
    GLint prog, tex, abuf, ebuf, vao, fbo, vp[4];
    GLboolean blend, depth, scissor;
};

static void saveGL(GLState& s) {
    glGetIntegerv(GL_CURRENT_PROGRAM,            &s.prog);
    glGetIntegerv(GL_TEXTURE_BINDING_2D,         &s.tex);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING,       &s.abuf);
    glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &s.ebuf);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING,       &s.vao);
    glGetIntegerv(GL_FRAMEBUFFER_BINDING,        &s.fbo);
    glGetIntegerv(GL_VIEWPORT,                   s.vp);
    s.blend   = glIsEnabled(GL_BLEND);
    s.depth   = glIsEnabled(GL_DEPTH_TEST);
    s.scissor = glIsEnabled(GL_SCISSOR_TEST);
}

static void restoreGL(const GLState& s) {
    glUseProgram(s.prog);
    glBindTexture(GL_TEXTURE_2D, s.tex);
    glBindBuffer(GL_ARRAY_BUFFER, s.abuf);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, s.ebuf);
    glBindVertexArray(s.vao);
    glBindFramebuffer(GL_FRAMEBUFFER, s.fbo);
    glViewport(s.vp[0], s.vp[1], s.vp[2], s.vp[3]);
    s.blend   ? glEnable(GL_BLEND)        : glDisable(GL_BLEND);
    s.depth   ? glEnable(GL_DEPTH_TEST)   : glDisable(GL_DEPTH_TEST);
    s.scissor ? glEnable(GL_SCISSOR_TEST) : glDisable(GL_SCISSOR_TEST);
}

/* ==============================
   Hook VanillaCameraAPI
================================ */

static int hook_getPlayerViewPerspective(void* thisPtr) {
    if (g_perspective >= 0) return g_perspective;
    if (g_getPlayerViewPerspective_orig)
        return g_getPlayerViewPerspective_orig(thisPtr);
    return 0;
}

static bool hookCameraAPI() {
    void* mcLib = dlopen("libminecraftpe.so", RTLD_NOLOAD);
    if (!mcLib) mcLib = dlopen("libminecraftpe.so", RTLD_LAZY);
    if (!mcLib) { LOGE("dlopen falhou"); return false; }

    const char* typeinfoName = "16VanillaCameraAPI";
    size_t nameLen = strlen(typeinfoName);

    // Varre /proc/self/maps procurando enderecos em libminecraftpe.so
    auto scanMaps = [](const char* perm, auto callback) -> bool {
        std::ifstream maps("/proc/self/maps");
        std::string line;
        while (std::getline(maps, line)) {
            if (line.find("libminecraftpe.so") == std::string::npos) continue;
            if (line.find(perm) == std::string::npos) continue;
            uintptr_t start, end;
            if (sscanf(line.c_str(), "%lx-%lx", &start, &end) == 2)
                if (callback(start, end)) return true;
        }
        return false;
    };

    // 1) nome do typeinfo
    uintptr_t typeinfoNameAddr = 0;
    scanMaps("r--p", [&](uintptr_t s, uintptr_t e) -> bool {
        for (uintptr_t a = s; a < e - nameLen; a++)
            if (memcmp((void*)a, typeinfoName, nameLen) == 0) {
                typeinfoNameAddr = a; return true;
            }
        return false;
    });
    if (!typeinfoNameAddr) { LOGE("typeinfo name nao encontrado"); return false; }

    // 2) typeinfo struct
    uintptr_t typeinfoAddr = 0;
    scanMaps("r--p", [&](uintptr_t s, uintptr_t e) -> bool {
        for (uintptr_t a = s; a < e - sizeof(void*); a += sizeof(void*))
            if (*(uintptr_t*)a == typeinfoNameAddr) {
                typeinfoAddr = a - sizeof(void*); return true;
            }
        return false;
    });
    if (!typeinfoAddr) { LOGE("typeinfo nao encontrado"); return false; }

    // 3) vtable
    uintptr_t vtableAddr = 0;
    scanMaps("r--p", [&](uintptr_t s, uintptr_t e) -> bool {
        for (uintptr_t a = s; a < e - sizeof(void*); a += sizeof(void*))
            if (*(uintptr_t*)a == typeinfoAddr) {
                vtableAddr = a + sizeof(void*); return true;
            }
        return false;
    });
    if (!vtableAddr) { LOGE("vtable nao encontrada"); return false; }

    // 4) slot 7 = getPlayerViewPerspectiveOption
    uintptr_t* slot = (uintptr_t*)(vtableAddr + 7 * sizeof(void*));
    g_getPlayerViewPerspective_orig = (int(*)(void*))(*slot);

    uintptr_t page = (uintptr_t)slot & ~(4095UL);
    if (mprotect((void*)page, 4096, PROT_READ | PROT_WRITE) != 0) {
        LOGE("mprotect falhou"); return false;
    }
    *slot = (uintptr_t)hook_getPlayerViewPerspective;
    mprotect((void*)page, 4096, PROT_READ);

    LOGI("VanillaCameraAPI hookada");
    return true;
}

/* ==============================
   Menu ImGUI
================================ */

static const char* perspLabel(int p) {
    if (p == 0) return "1a Pessoa";
    if (p == 1) return "3a Pessoa (costas)";
    if (p == 2) return "3a Pessoa (frente)";
    return "Jogo controla";
}

static void drawMenu() {
    ImGui::SetNextWindowPos(ImVec2(10, 100), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(240, 0), ImGuiCond_FirstUseEver);
    ImGui::Begin("Perspectiva", nullptr, ImGuiWindowFlags_AlwaysAutoResize);

    ImGui::Text("Atual: %s", perspLabel(g_perspective));
    ImGui::Separator();

    if (ImGui::Button("1a Pessoa",           ImVec2(-1, 40))) g_perspective = 0;
    if (ImGui::Button("3a Pessoa (costas)",  ImVec2(-1, 40))) g_perspective = 1;
    if (ImGui::Button("3a Pessoa (frente)",  ImVec2(-1, 40))) g_perspective = 2;
    ImGui::Spacing();
    if (ImGui::Button("Ciclar ->",           ImVec2(-1, 40))) {
        if (g_perspective < 0) g_perspective = 0;
        else g_perspective = (g_perspective + 1) % 3;
    }
    ImGui::Spacing();
    if (ImGui::Button("Liberar (jogo controla)", ImVec2(-1, 30)))
        g_perspective = -1;

    ImGui::End();
}

/* ==============================
   Setup & Render ImGUI
================================ */

static void setupImGui() {
    if (g_imguiInitialized || g_width <= 0 || g_height <= 0) return;
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init("#version 300 es");
    g_imguiInitialized = true;
    LOGI("ImGui inicializado");
}

static void render() {
    if (!g_imguiInitialized) return;
    GLState s;
    saveGL(s);

    ImGuiIO& io    = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)g_width, (float)g_height);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(g_width, g_height);
    ImGui::NewFrame();
    drawMenu();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    restoreGL(s);
}

/* ==============================
   Hook eglSwapBuffers
================================ */

static EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surf) {
    if (!orig_eglSwapBuffers) return EGL_FALSE;

    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT) return orig_eglSwapBuffers(dpy, surf);

    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH,  &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 500 || h < 500) return orig_eglSwapBuffers(dpy, surf);

    if (g_targetContext == EGL_NO_CONTEXT) {
        g_targetContext = ctx;
        g_targetSurface = surf;
    }
    if (ctx != g_targetContext || surf != g_targetSurface)
        return orig_eglSwapBuffers(dpy, surf);

    g_width  = w;
    g_height = h;
    setupImGui();
    render();

    return orig_eglSwapBuffers(dpy, surf);
}

/* ==============================
   Hook input
================================ */

static int32_t (*orig_input)(void*, void*, bool, long, uint32_t*, AInputEvent**) = nullptr;
static int32_t hook_input(void* thiz, void* a1, bool a2, long a3,
                          uint32_t* a4, AInputEvent** ev) {
    int32_t r = orig_input ? orig_input(thiz, a1, a2, a3, a4, ev) : 0;
    if (r == 0 && ev && *ev && g_imguiInitialized)
        ImGui_ImplAndroid_HandleInputEvent(*ev);
    return r;
}

/* ==============================
   Thread principal
================================ */

static void* mainThread(void*) {
    sleep(3);
    GlossInit(true);

    if (!hookCameraAPI())
        LOGE("Falha ao hookar camera — perspectiva nao vai funcionar");

    GHandle hegl = GlossOpen("libEGL.so");
    if (!hegl) { LOGE("libEGL.so nao encontrada"); return nullptr; }

    void* swap = (void*)GlossSymbol(hegl, "eglSwapBuffers", nullptr);
    if (!swap)  { LOGE("eglSwapBuffers nao encontrado"); return nullptr; }
    GlossHook(swap, (void*)hook_eglSwapBuffers, (void**)&orig_eglSwapBuffers);

    void* inputSym = (void*)GlossSymbol(
        GlossOpen("libinput.so"),
        "_ZN7android13InputConsumer7consumeEPNS_26InputEventFactoryInterfaceEblPjPPNS_10InputEventE",
        nullptr);
    if (inputSym)
        GlossHook(inputSym, (void*)hook_input, (void**)&orig_input);

    g_modInitialized = true;
    LOGI("PerspectiveMod carregado com sucesso");
    return nullptr;
}

__attribute__((constructor))
void perspective_init() {
    pthread_t t;
    pthread_create(&t, nullptr, mainThread, nullptr);
}
